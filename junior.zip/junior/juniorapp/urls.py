from django.urls import path
from .views import *

urlpatterns = [
    path('', index, name='home'),
    path('about/', about, name='about'),
    path('portfolio/', portfolio, name='portfolio'),
    path('contact/', contact, name='contact'),
    path('blog/', blog, name='blog'),
    path('add_post/', add_post, name='add_post'),
    path('post/<slug:post_slug>/', show_post, name='post'),

]